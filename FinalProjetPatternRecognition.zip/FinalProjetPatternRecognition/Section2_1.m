clc
clear
close all
%%%%%%%% Loading Datas %%%%%%%%%%
data=importdata('Urban_R162.mat');
data1=importdata('groundTruth.mat');
nClassNumber = 6;

%%%%%%%% Get size of image data set and convert it to 2D %%%%%%%%
InputImage = data.Y;

%%%%%%%% convert Ground Truth Image to 2D %%%%%%%%
GroundTruthImage1D = hyperConvert2d(data1.groundTruth);

%%%%%%%% Patch image data set to Test and Train%%%%%%%%
r =[];
TrainingRate = 100 - 70;
[r, Checking_Data,Checking_Result,Training_Data,Training_Result] = Select_Check_TrainingClass(GroundTruthImage1D',InputImage',TrainingRate,nClassNumber,r);
nPix=[];
for i=1:nClassNumber
    I=find(Training_Result == i);
    nPix=[nPix;size(I,1)];
end
nPix;
save ('My_Test_Train.mat','Checking_Data','Checking_Result','Training_Data','Training_Result')

%%%%%%%% KNN %%%%%%%%
Model_KNN = fitcknn(Training_Data,Training_Result,'NumNeighbors',1);
Checking_Result_Predicted = predict(Model_KNN,Checking_Data);
Training_Result_Predicted = predict(Model_KNN,Training_Data);

CP = classperf(Checking_Result,Checking_Result_Predicted);
sprintf('Overall accuracy of kNN is %f%%',CP.CorrectRate*100)

ClassifiedImage = predict(Model_KNN,InputImage');
CP = classperf(GroundTruthImage1D,ClassifiedImage);
strOverallAcc = sprintf('Overall accuracy of classified image is %f%%',CP.CorrectRate*100)
h=data.nRow;w=data.nCol;
ClassifiedImage3D = hyperConvert3d(ClassifiedImage', h, w, 3);

%%% Test
MSE_Test=mean((Checking_Result_Predicted-Checking_Result).^2)
RMSE_Test=sqrt(MSE_Test)
R2_Test=1-(sum((Checking_Result_Predicted-Checking_Result).^2)/sum((Checking_Result-mean(Checking_Result)).^2))

%%% Train
MSE_Train=mean((Training_Result_Predicted-Training_Result).^2)
RMSE_Train=sqrt(MSE_Train)
R2_Train=1-(sum((Training_Result_Predicted-Training_Result).^2)/sum((Training_Result-mean(Training_Result)).^2))

subplot 121
imagesc(data1.groundTruth);
axis off
title('Ground Truth Image')

subplot 122
imagesc(ClassifiedImage3D)
axis off
title(strOverallAcc)