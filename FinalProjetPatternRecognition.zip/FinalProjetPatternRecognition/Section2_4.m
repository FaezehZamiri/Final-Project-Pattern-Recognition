clc
clear
close all
%%%%%%%% Loading Datas %%%%%%%%%%
data=importdata('Urban_R162.mat');
data1=importdata('groundTruth.mat');
nClassNumber = 7;

%%%%%%%% Get size of image data set and convert it to 2D %%%%%%%%
InputImage = data.Y;

%%%%%%%% convert Ground Truth Image to 2D %%%%%%%%
GroundTruthImage1D = hyperConvert2d(data1.groundTruth);

%%%%%%%% Patch image data set to Test and Train%%%%%%%%
r =[];
TrainingRate = 100 - 70;
[r, Checking_Data1,Checking_Result,Training_Data1,Training_Result] = Select_Check_TrainingClass(GroundTruthImage1D',InputImage',TrainingRate,nClassNumber,r);
nPix=[];
for i=1:nClassNumber
    I=find(Training_Result == i);
    nPix=[nPix;size(I,1)];
end
nPix;
save ('My_Test_Train.mat','Checking_Data1','Checking_Result','Training_Data1','Training_Result')

%%%%%%%% Feature Selection %%%%%%%%%%
%% Relieff Method 
[ranked,weight] = relieff(Training_Data1,Training_Result,10);
bar(weight(ranked));
xlabel('Predictor rank');
ylabel('Predictor importance weight');

%%%%%%%% Selecting Best Bands %%%%%%%%%%
% index=[100,114,120,124,127,130,133,134,136,137,141,142,143,145,147,148,150,153,154,157];
index=find(weight>0.0025);
for i=1:length(index)
    Training_Data(:,i)=Training_Data1(:,index(i));
    Checking_Data(:,i)=Checking_Data1(:,index(i));
end

%% NCA Method
mdl = fsrnca(Training_Data1,Training_Result,'Verbose',1);
figure()
plot(mdl.FeatureWeights,'ro')
grid on
xlabel('Feature index')
ylabel('Feature weight')
%%%%%%%% Selecting Best Bands %%%%%%%%%%
index=find(mdl.FeatureWeights>2);
%index=[2,51,57,70,71,83,84,96,116,124,139,144];
for i=1:length(index)
    Training_Data(:,i)=Training_Data1(:,index(i));
    Checking_Data(:,i)=Checking_Data1(:,index(i));
end

%%%%%%%% SVM-Scales %%%%%%%%
Testing_instance_matrix=Checking_Data;
Testing_label=Checking_Result;
Training_instance_matrix=Training_Data;
Training_label=Training_Result;

[Training_instance_matrix,minVn,maxVn] = SVM_Scale(2,Training_instance_matrix,[],[]);
[Testing_instance_matrix,minV,maxV] = SVM_Scale(2,Testing_instance_matrix,[],[]);
[Training_label,minVm,maxVm] = SVM_Scale(2,Training_label,[],[]);
[Testing_label,minV,maxV] = SVM_Scale(2,Testing_label,[],[]);

% Model Selection with Grid Search
%% Useing linear kernel
tic
l=1;
%bestc=22.6274;
for i=1:0.25:5
    bestc(l) = 2^i;% The range for c is 2^1 , 2^1.25 , ... 2^5

    cmd = [' -s 0 -t 0  -c ', num2str(200)];

    %Make model from Training datas
    model_svr = svmtrain(Training_label, Training_instance_matrix, cmd);

    %Predict Testing datas
    [Predict_testing_label, Accuracy_testing, dec_values_testing] = svmpredict(Testing_label,Testing_instance_matrix, model_svr);

    %Predict Training datas
    [Predict_training_label, Accuracy_training, dec_values_training]= svmpredict(Training_label,Training_instance_matrix, model_svr);

    %Result for Testing datas 
    MSE_Test(l) = mean((Predict_testing_label-Testing_label).^2);
    RMSE_Test(l) = sqrt(MSE_Test(l)); 
    NRMS_Test(l) = sqrt(MSE_Test(l)) / std(Testing_label);
    R2_Test(l)= Accuracy_testing(1);

    %Result for Training datas 
    R2_Train(l)= Accuracy_training(1);
    MSE_Train(l) = mean((Predict_training_label-Training_label).^2);
    RMSE_Train(l) = sqrt(MSE_Train(l));
    NRMS_Train(l)= sqrt(MSE_Train(l)) / std(Training_label);
        
    l=l+1;
end
toc

%%%%%%%% Results %%%%%%%%%%
Log_C=log2(bestc)
Prediction_Accuracy_Test=R2_Test;
Prediction_Accuracy_Trian=R2_Train;

index= find(R2_Test==max(R2_Test));
Best_Accuracy=R2_Test(index)
Best_C=bestc(index)
Rmse_Test=RMSE_Test(index)
Rmse_Trian=RMSE_Train(index)
r2_Trian=R2_Train(index)

figure;plot(Log_C,Prediction_Accuracy_Test)
xlabel('Log(C)')
ylabel('Prediction Accuracy for Test Datas')

figure;plot(Log_C,RMSE_Test)
xlabel('Log(C)')
ylabel('RMSE for Test Datas')

figure;plot(Log_C,Prediction_Accuracy_Trian)
xlabel('Log(C)')
ylabel('Prediction Accuracy for Trian Datas')

figure;plot(Log_C,RMSE_Train)
xlabel('Log(C)')
ylabel('RMSE for Trian Datas')
%% Useing radial basis function
tic 
l=1;
for i=1:0.25:5
    for j=-7:0.25:-3
        bestc(l) = 2^i;% The range for c is 2^1 , 2^1.25 , ... 2^5
        bestg(l) = 2^j;% The range for g is 2^-7 , 2^-6.25 , ... 2^-3
        
        cmd = ['-q -s 0 -c ', num2str(bestc(l)), ' -g ', num2str(bestg(l))];
        
        %Make model from Training datas
        model_svr = svmtrain(Training_label, Training_instance_matrix, cmd);
        
        %Predict Testing datas
        [Predict_testing_label, Accuracy_testing, dec_values_testing] = svmpredict(Testing_label,Testing_instance_matrix, model_svr);
        
        %Predict Training datas
        [Predict_training_label, Accuracy_training, dec_values_training]= svmpredict(Training_label,Training_instance_matrix, model_svr);
        
        %Result for Testing datas 
        MSE_Test(l) = mean((Predict_testing_label-Testing_label).^2);
        RMSE_Test(l) = sqrt(MSE_Test(l)); 
        NRMS_Test(l) = sqrt(MSE_Test(l)) / std(Testing_label);
        R2_Test(l)= Accuracy_testing(1);
        
        %Result for Training datas 
        R2_Train(l)= Accuracy_training(1);
        MSE_Train(l) = mean((Predict_training_label-Training_label).^2);
        RMSE_Train(l) = sqrt(MSE_Train(l));
        NRMS_Train(l)= sqrt(MSE_Train(l)) / std(Training_label);
        
    l=l+1;
    end
end
toc 

Log_C=log2(bestc);Log_Gamma=log2(bestg);
Prediction_Accuracy_Test=R2_Test.*100;
Prediction_Accuracy_Trian=R2_Train.*100;

index= find(R2_Test==max(R2_Test));
Best_Accuracy=R2_Test(index)
Best_C=bestc(index)
Best_Gamma=bestg(index)
Rmse_Test=RMSE_Test(index)
Rmse_Trian=RMSE_Train(index)
r2_Trian=R2_Train(index)


