clc
clear
close all
%%%%%%%% Loading Datas %%%%%%%%%%
data=importdata('Urban_R162.mat');
data1=importdata('groundTruth.mat');
nClassNumber = 7;

%%%%%%%% Get size of image data set and convert it to 2D %%%%%%%%
InputImage = data.Y;

%%%%%%%% convert Ground Truth Image to 2D %%%%%%%%
GroundTruthImage1D = hyperConvert2d(data1.groundTruth);

%%%%%%%% Patch image data set to Test and Train%%%%%%%%
r =[];
TrainingRate = 100 - 70;
[r, Checking_Data1,Checking_Result,Training_Data1,Training_Result] = Select_Check_TrainingClass(GroundTruthImage1D',InputImage',TrainingRate,nClassNumber,r);
nPix=[];
for i=1:nClassNumber
    I=find(Training_Result == i);
    nPix=[nPix;size(I,1)];
end
nPix;
save ('My_Test_Train.mat','Checking_Data1','Checking_Result','Training_Data1','Training_Result')
InputImage=InputImage';
%%%%%%%% Feature Selection %%%%%%%%%%
%% Relieff Method 
[ranked,weight] = relieff(Training_Data1,Training_Result,10);
bar(weight(ranked));
xlabel('Predictor rank');
ylabel('Predictor importance weight');

%%%%%%%% Selecting Best Bands %%%%%%%%%%
% index=[100,114,120,124,127,130,133,134,136,137,141,142,143,145,147,148,150,153,154,157];
index=find(weight>0.0025);
for i=1:length(index)
    Training_Data(:,i)=Training_Data1(:,index(i));
    Checking_Data(:,i)=Checking_Data1(:,index(i));
    InputImage1(:,i)=InputImage(:,index(i));
end

%% NCA Method
mdl = fsrnca(Training_Data1,Training_Result,'Verbose',1);
figure()
plot(mdl.FeatureWeights,'ro')
grid on
xlabel('Feature index')
ylabel('Feature weight')
%%%%%%%% Selecting Best Bands %%%%%%%%%%
% index=[2,51,57,70,71,83,84,96,116,124,139,144];
index=find(mdl.FeatureWeights>4);
for i=1:length(index)
    Training_Data(:,i)=Training_Data1(:,index(i));
    Checking_Data(:,i)=Checking_Data1(:,index(i));
    InputImage1(:,i)=InputImage(:,index(i));
end

%% %%%%%%%% KNN %%%%%%%%
Model_KNN = fitcknn(Training_Data,Training_Result,'NumNeighbors',1);
Checking_Result_Predicted = predict(Model_KNN,Checking_Data);
Training_Result_Predicted = predict(Model_KNN,Training_Data);

CP = classperf(Checking_Result,Checking_Result_Predicted);
sprintf('Overall accuracy of kNN is %f%%',CP.CorrectRate*100)

ClassifiedImage = predict(Model_KNN,InputImage1);
CP = classperf(GroundTruthImage1D,ClassifiedImage);
strOverallAcc = sprintf('Overall accuracy of classified image is %f%%',CP.CorrectRate*100)
h=data.nRow;w=data.nCol;
ClassifiedImage3D = hyperConvert3d(ClassifiedImage', h, w, 3);

% %%% Test
% MSE_Test=mean((Checking_Result_Predicted-Checking_Result).^2)
% RMSE_Test=sqrt(MSE_Test)
% R2_Test=1-(sum((Checking_Result_Predicted-Checking_Result).^2)/sum((Checking_Result-mean(Checking_Result)).^2))
% 
% %%% Train
% MSE_Train=mean((Training_Result_Predicted-Training_Result).^2)
% RMSE_Train=sqrt(MSE_Train)
% R2_Train=1-(sum((Training_Result_Predicted-Training_Result).^2)/sum((Training_Result-mean(Training_Result)).^2))
pre1=Checking_Result_Predicted;
per2=Training_Result_Predicted;

%%%%%test
SSE=sum((Checking_Result-pre1).^2);
Syy=sum((Checking_Result-mean(Checking_Result)).^2);
R2_test=(Syy-SSE)/(Syy)

%%%%train
SSE1=sum((Training_Result-per2).^2);
Syy1=sum((Training_Result-mean(Training_Result)).^2);
R2_train=(Syy1-SSE1)/(Syy1)
 
MSE_test=mean((pre1-Checking_Result).^2);
RMSE_test=sqrt(MSE_test)

MSE_train=mean((per2-Training_Result).^2);
RMSE_train=sqrt(MSE_train)

subplot 121
imagesc(data1.groundTruth);
axis off
title('Ground Truth Image')

subplot 122
imagesc(ClassifiedImage3D)
axis off
title(strOverallAcc)