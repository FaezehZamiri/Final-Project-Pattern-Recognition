clc
clear
close all
%%%%%%%% Loading Datas %%%%%%%%%%
data=importdata('Depth_Mapping_Data.mat');

Testing_instance_matrix1=data.Checking_Data;
Testing_label=data.Checking_Result;
Training_instance_matrix1=data.Training_Data;
Training_label=data.Training_Result;

%%%%%%%% Feature Selection %%%%%%%%%%
%% Relieff Method 
[ranked,weight] = relieff(Training_instance_matrix1,Training_label,10);
bar(weight(ranked));
xlabel('Predictor rank');
ylabel('Predictor importance weight');

%%%%%%%% Selecting Best Bands %%%%%%%%%%
index=find(weight>0.0025);
for i=1:length(index)
    Training_instance_matrix(:,i)=Training_instance_matrix1(:,index(i));
    Testing_instance_matrix(:,i)=Testing_instance_matrix1(:,index(i));
end

%% NCA Method
mdl = fsrnca(Training_instance_matrix1,Training_label,'Verbose',1);
figure()
plot(mdl.FeatureWeights,'ro')
grid on
xlabel('Feature index')
ylabel('Feature weight')
%%%%%%%% Selecting Best Bands %%%%%%%%%%
index=find(mdl.FeatureWeights>4);
for i=1:length(index)
    Training_instance_matrix(:,i)=Training_instance_matrix1(:,index(i));
    Testing_instance_matrix(:,i)=Testing_instance_matrix1(:,index(i));
end
%%%%%%%% Regression %%%%%%%%%%
model=fitlm(Training_instance_matrix,Training_label)
predict_y=predict(model,Testing_instance_matrix);

%%%%%%%% Results %%%%%%%%%%
% Test 
MSE_Test=mean((predict_y-Testing_label).^2)
RMSE_Test=sqrt(MSE_Test)
R2_Test=1-(sum((predict_y-Testing_label).^2)/sum((Testing_label-mean(Testing_label)).^2))
NRMS_Test= sqrt(MSE_Test) / std(Testing_label)

% Train
RMSE_Trian=model.RMSE
R2_Trian=model.Rsquared.ordinary
COEF_Trian=model.Coefficients;

Prediction_Accuracy_Test=R2_Test.*100
Prediction_Accuracy_Trian=R2_Trian.*100

