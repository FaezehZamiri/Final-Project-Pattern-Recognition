%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [r,Checking_Data,Checking_Result,Training_Data,Training_Result]=Select_Check_TrainingClass(Ground_Truth,Data,Check_Percentage,Number_Class,RandData)
    %t=find(Ground_Truth<Number_Class+1&Ground_Truth>0);
    t=find(Ground_Truth<Number_Class+1);
    %t=find(Ground_Truth<Number_Class);
    Data2=Data(t,:);
    Ground_Truth2=Ground_Truth(t,1);
    [n m]=size(Ground_Truth2);
    Number_Check=round(n*(Check_Percentage/100));
    if isempty(RandData)
        r = randsample(n,Number_Check);
    else
        r = RandData;
    end
    A(1:n,1)=1;
    A(r,1)=0;
    Checking_Data=Data2(r,:);
    Checking_Result=Ground_Truth2(r,1);
    B=find(A);
    Training_Data=Data2(B,:);
    Training_Result=Ground_Truth2(B,1);