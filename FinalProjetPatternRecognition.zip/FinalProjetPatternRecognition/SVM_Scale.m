function [Scale_Data,minVal,maxVal] = SVM_Scale(nMode,Data,minVal_In,maxVal_In)
minVal = min(Data,[],1);
maxVal = max(Data,[],1);

if ~isempty(minVal_In)
    minVal = minVal_In;
end

if ~isempty(maxVal_In)
    maxVal = maxVal_In;
end

if (maxVal == minVal)
    Scale_Data = zeros(size(Data));
else
    if nMode == 1 % Scaling to [0,1]
        Scale_Data = (Data - repmat(minVal,size(Data,1),1))*spdiags(1./(maxVal-minVal)',0,size(Data,2),size(Data,2));
        %Scale_Data = (Data - minVal)./ (maxVal-minVal);
    elseif nMode == 2 % Scaling to [-1,1]
        Scale_Data = 2*(Data - repmat(minVal,size(Data,1),1))*spdiags(1./(maxVal-minVal)',0,size(Data,2),size(Data,2))-1;
        %Scale_Data = 2*(Data - minVal)./ (maxVal-minVal) -1;
    end
end